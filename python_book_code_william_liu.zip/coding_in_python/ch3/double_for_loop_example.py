#double for loop example
for i in range (3):
    for j in range (3):
        print('[' + str(i), j, end="] ")
