#1. list-driven for loop
languages = ["Python", "Java", "C/C++"]
for x in languages:
    print(x, end = " ")
else:
    print()  

#2. set-driven for loop
languages = ("Python", "Java", "C/C++")
for x in languages:
    print(x, end = " ")
else:
    print()     
 
#3. loop through a string
python = 'Python'
for letter in python:
    print(letter.upper(), end = "")