#1. continue statement
for i in range(1, 5):
    if(i == 2):
        print(' - ', i, 'skipped - ', end = ' ')
        continue
    print(i, end = ' ')
else:
    print()
    
#2. break statement
for i in range(1, 5):
    if(i == 3):
        print(': broke out at i = 3')
        break
    print(i, end = ' ')
        
#3. break statement
for i in range(1, 5):
    if(i == 2):
        print(' - ', i, ' passed - ', end = ' ')
        pass
    else:
        print(i, end = ' ')
