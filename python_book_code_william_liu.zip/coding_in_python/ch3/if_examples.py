#1. compare two numbers
a = 123
b = 123 #12 #b = 456
if b > a:
    print(b, 'is greater than ', a)
elif a == b:
    print(b, 'is equal to ', a)
else:
    print(b, 'is smaller than ', a)

#2. compare two strings
str1 = 'abc'
str2 = 'xyz'
if str1 > str2:
    print(str1, 'is greater than ', str2)
elif str1 == str2:
    print(str1, 'is equal to ', str2)
else:
    print(str1, 'is smaller than ', str2)
    
#3. compare two lists
list1 = [1, 2, 3]
list2 = [4, 5, 6]
if list1 > list2:
    print(list1, 'is greater than ', list2)
elif list1 == list2:
    print(list1, 'is equal to ', list2)
else:
    print(list1, 'is smaller than ', list2)
    
#4. compare two lists
list1 = [1, 2, 3]
list2 = [2, 1, 3]
if list1 > list2:
    print(list1, 'is greater than ', list2)
elif list1 == list2:
    print(list1, 'is equal to ', list2)
else:
    print(list1, 'is smaller than ', list2)
    
#5. compare two lists
list1 = [1, 2, 3]
list2 = [1, 2, 1]
if list1 > list2:
    print(list1, 'is greater than ', list2)
elif list1 == list2:
    print(list1, 'is equal to ', list2)
else:
    print(list1, 'is smaller than ', list2)
    
#6 check if None    
x = 123

if x is None:
    print("x is None")
else:
    print("x is not None")
    
#7 check if None    
y = None

if y is None:
    print("y is None")
else:
    print("y is not None")