# while-loop example
i = 0
while i < 10:
    print(i, end=' ')
    i += 1
else:
    print("\nexited at i =", i)
