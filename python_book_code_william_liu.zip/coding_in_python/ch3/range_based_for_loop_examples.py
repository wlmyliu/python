#1 range-based start with default start = 0 and step = 1
for x in range(3):
    print(x, end=' ')
else:
    print('exited with x =',x) 

#2 range-based with start = 2 and step = 1
for x in range(2, 5):
    print(x, end=' ')
else:
    print('exited with x =',x) 

#3 range-based with start = 1, end = 10 and step = 3
for x in range(1, 10, 3):
    print(x, end=' ')
else:
    print('exited with x =',x) 
    
#4 range-based with start = 1, end = 10 and step = 3
for x in range(1, -10, -3):
    print(x, end=' ')
else:
    print('exited with x =',x) 