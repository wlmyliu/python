def print_hello():
    print("From ch1__main_exaple: Hello, Python!")  
    
def main():
    print_hello()

if __name__ == "__main__":
    main()