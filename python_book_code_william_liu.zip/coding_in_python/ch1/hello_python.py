hello_str = "Hello World!"
print(hello_str)

