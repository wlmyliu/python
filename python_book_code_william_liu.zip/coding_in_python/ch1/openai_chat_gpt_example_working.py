
from openai import OpenAI
import util as util

my_api_key = util.get_api_key()
client = OpenAI(api_key=my_api_key);

def chat_gpt(prompt):
    print(prompt)
    response = client.chat.completions.create(
        model = "gpt-3.5-turbo",
        temperature = 0.7,
        messages = [{"role": "user", "content": prompt}]
    )
    return response.choices[0].message.content.strip()

question = "Question:\nplease show me most popular programming languages up to 2023\n"
response = chat_gpt(question)
print('Response:\n', response)
