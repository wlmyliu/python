'''
block comments
how to import the math package
'''

import math
 
x = 3
y = 4
z = math.sqrt(x*x + y*y) #convert z to string before concatenating
print(" sqrt(x^2 + y^2) = " + str(z))
