def print_hello():
    print("Hello, Python!")  
    
def main():
    print_hello()

if __name__ == "__main__":
    main()