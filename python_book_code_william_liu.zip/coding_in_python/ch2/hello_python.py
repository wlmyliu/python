'''
Created on Nov 20, 2023
'''
# create a string variable
hello_python = "Hello, Python!";hello_python1 = "Hello Again, Python!";
#print a string variable
print(hello_python)
print(hello_python1)