
import math
def sqrt_and_add (x, y):
    sqrt = math.sqrt(x*x + y*y) 
    sum = x + y
    return sqrt, sum