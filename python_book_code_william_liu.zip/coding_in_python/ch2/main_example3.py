import math_example

def print_hello_again():
    print("Hello Again, Python!")  
    
def main():
    print_hello_again()
    print(math_example.sqrt_and_add(3, 4))

if __name__ == "__main__":
    main()