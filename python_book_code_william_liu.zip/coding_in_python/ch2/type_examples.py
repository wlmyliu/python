i = 99
print('type of i:', type(i))

x = 99.99
print('type of x:', type(x))

a_str = 'python'
print('type of a_str:', type(str))

j = 3
print('a_str + j:', a_str, j)

#print(a_str + j)
#print(a_str + str(j))