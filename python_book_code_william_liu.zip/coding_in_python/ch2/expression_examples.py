x = 99
y = 1

# arithmetic operation
add = x + y 
subtract = x - y 
multiply = x * y 
divide = x / y 
  
print('add:', add) 
print('subtract:', subtract) 
print('multiply:', multiply) 
print('divide:', divide)

x = 90
y = 10.0
  
z = x + y
print("add with different types: ", z)

# relational expression
xy = x < y
print('relational expression:', xy)

xyz = xy and z > x

print('logical expression add:', xyz)

xyz = xy or z > x

print('logical expression or:', xyz)

xyz = not z > x

print('logical expression not:', xyz)