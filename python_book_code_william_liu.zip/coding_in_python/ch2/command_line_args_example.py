import sys
 
n = len(sys.argv) # # of arguments
print("# of arguments input:", n)
 
# Arguments passed
print("Python script name:", sys.argv[0])
 
print("Arguments input:")
for i in range(1, n):
    print(sys.argv[i])

