str = 'Hello'
str += ", Python!"
print('1. str compound: ', str)

i = 90
i += 10
print('2. integer add compound: ', i)

j = 90
j -= 10
print('3. integer subtract compound: ', j)

k = 90
k *= 10
print('4. integer multiply compound: ', k)

l = 90
l /= 7
print('5. integer divide compound: ', l)

m = 90
m //= 7
print('6. integer divide truncate compound: ', m)

n = 90
n //= 7.0
print('7. float divide truncate compound: ', n)