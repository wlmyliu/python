# Python print options
str_abc = 'abc'
i = 123
#print(str + i) # wrong
print(str_abc + str(i) + " <- type converted") # need type conversion
print(str_abc, i, ' <- used positional arguments')   # or using positional arguments
print(i, ' <- no type conversion needed here') #no need for type conversion here
print(str_abc, i, ' <- default separator overwritten', sep=',') # overwrite default space separator 
print(f'Hello, {str_abc}{i}', ' <- f-string based print') #avoid type conversion with f-string

b = True
print(b, '<- boolean print') # print boolean

number_list = [1, 2, 3]
print(number_list, ' <- a list printed')  #print list

number_tuple = (1, 2, 3)
print(number_tuple, ' <- a tuple printed') # print tuple

fruit_set = {'apple', 'orange', 'peach'}
print(fruit_set, ' <- a set printed') #print set

prod_dictionary = {'brand' : 'iPhone', 'model' : '15 Pro'}
print(prod_dictionary, ' <- a dictionary printed') #print dictionary