#from ch1 import ch1_main_example 
#import ch1_main_example from ch1
#import print_hello from ch1_main_example 
#import ch1
#import ch1.ch1_main_example
#import print_hello from ch1_main_example
''' this also works
import sys
sys.path.insert(0, '../ch1')
from ch1_main_example import print_hello
'''
''' this would work
import main_example0 # import the entire module
from ch1_main_example import print_hello # from <module> import <function>
'''
import ch1_main_example
def print_hello_again():
    print("ch2: Hello Again, Python!")  
    
def main():
    print_hello_again()

if __name__ == "__main__":
    main()

#print_hello()    
#main_example0.print_hello()
#ch1_main_example.print_hello()
