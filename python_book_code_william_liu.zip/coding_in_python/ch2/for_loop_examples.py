print('increment 1: start with 0 and a default step of 1:')
for i in range(0, 3):
    print(i)

print('increment 2: start with 1 and a step of 2:')
for i in range(1, 3, 2):
    print(i)

print('\ndecrement 1: start with 3 and a step of -1 ')
for i in range(3, 0, -1):
    print(i)
   
print('\ndecrement 2: start with 3 and a step of -2 ')
for i in range(3, -2, -2):
    print(i)
   
print('\ndecrement 3: start with 3 and a step of -2 ')
for i in range(3, 4, -2):
    print(i) 