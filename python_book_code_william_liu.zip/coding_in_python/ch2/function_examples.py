import sys

bonus_pct = 0.15; # assuming 15% bonus pay

def get_pay (wage, hours):
    return wage * hours

def get_bonus (salary):
    return bonus_pct * salary

def done():
    print("done")

n = len(sys.argv) # # of arguments
print("# of arguments input:", n)
 
# Arguments passed
print("Python script name:", sys.argv[0])

wage = 62.5 # hourly
hours = float(sys.argv[1])
print("hours worked:", hours)

pay = get_pay (wage, hours)
print("You have made $" + str(pay), " for ", hours, "hours worked!")

bonus = get_bonus (pay)
print("Your bonus would be $" +str(bonus),  " for ", hours, "hours worked!")
        
done ()