import time
from time import gmtime, strftime
from datetime import datetime

#1 GMT time and local time
gmt_time = time.gmtime()

print("GMT time: ", time.strftime("%a, %d %b %Y %I:%M:%S %p %Z", gmt_time))
print("local: ", strftime("%a, %d %b %Y %I:%M:%S %p %Z"))

#2. current time in seconds
start_time = time.time()
print("\nstart_time = ", start_time)

#3. sleep
n = 5
print("\nsleep", n, "seconds")
time.sleep(n) # sleep n seconds

#4. time elapsed
curr_time = time.time()
elapsed_time = int(curr_time - start_time)
print("\ntime elapsed = ", elapsed_time, " seconds")

#5. curr time
now = datetime.now()
current_time = now.strftime("%H:%M:%S")
print("\nCurrent Time =", current_time)


