#sys module example_1
import sys

#1. display python interpreter installed
print('sys.version:', sys.version, '\n')

#2. system path
print('sys.path:', sys.path, '\n')

#3. sys.stdout and sys.stdin
sys.stdout.write('sys.stdout: ' + 'Hello, Python!' + '\n\n')

sys.stdout.write('sys.stdin for-loop: Enter a line or q to break\n')
for line in sys.stdin: 
    if 'q' == line.rstrip(): 
        sys.stdout.write('q: exited the for-loop\n')
        break
    print(f'line input : {line}') 

sys.exit("\nsys.exit executed!")    