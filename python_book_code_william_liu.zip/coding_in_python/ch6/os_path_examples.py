#os module example_1

import os

#1. display current working directory or path
cwd = os.getcwd() 
print("current working dir:", cwd) 

curr_path = os.path.dirname(os.path.abspath(__file__))
print("current path:", curr_path) 

#2. display parent directory
parent_dir = os.path.dirname(curr_path)
print("\nparent dir:", parent_dir)

#3. change to parent dir if exists
dir_exist = os.path.exists(parent_dir) 

if dir_exist:
    os.chdir(parent_dir)
    cwd = os.getcwd()    
    print("\nchanged to parent dir:", cwd) 
else:
    print(parent_dir, "does not exist") 
