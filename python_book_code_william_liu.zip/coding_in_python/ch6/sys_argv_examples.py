#sys module example_1
import sys

#collect input args with sys.argv
n = len(sys.argv)
print("# of arguments passed:", n)
print("name of the Python script executed:", sys.argv[0])
print("all args entered:", end = " ")

argv_sum = 0
for i in range(1, n):
    print(sys.argv[i], end = " ")
    argv_sum += int(sys.argv[i])

print("\nargv_sum = ", argv_sum)

#display sys modules
#print('sys.modules: ', str(sys.modules).replace(",", "\n"))