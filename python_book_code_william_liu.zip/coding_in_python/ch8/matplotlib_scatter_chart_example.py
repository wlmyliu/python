import pandas as pd
from matplotlib import pyplot as plt

#1. define data file and figure properties
data_file = 'weather_samples.csv'
attrib_x = "max_temp_f"
attrib_y = "max_wind_gust_kts"
title = "station's scatter plot for " + attrib_y + " vs " + attrib_x
width = 10; height = 7

grid = True
linewidth = 1.5

#2. set plt fig and axes
def get_fig_ax():
    fig, ax = plt.subplots(figsize=(width, height))
    ax.grid(grid)

    ax.set_xlabel(attrib_x)  # Add an x-label to the axes.
    ax.set_ylabel(attrib_y)  # Add a y-label to the axes.
    ax.set_title(title)  # Add a title to the chart.
    return fig, ax

#3.define a function for getting geo-station dictionary
def get_geo_station_dict(df):
    df_geos = df.geo.unique()

    geo_station_dict = {}
    for geo in df_geos:
        geo_stations = df[df.geo == geo]['station'].unique()
        geo_station_dict[geo] = geo_stations
    return geo_station_dict

#4. get DataFrame object as the data source
df = pd.read_csv(data_file)

#5. get geo-station dictionary for charting station by station
geo_station_dict = get_geo_station_dict(df)
for key in geo_station_dict.keys():
    stations = geo_station_dict.get(key)

#6. plot the chart
fig, ax = get_fig_ax()
for key in geo_station_dict.keys():
    stations = geo_station_dict.get(key)
    for station in stations:
        x = df[df.station == station][attrib_x]
        max_temp_series = df[df.station == station][attrib_y]
        y = max_temp_series.to_numpy()

        ax.scatter(x, y, s = 20, label = station) 

#7. complete the chart by adding legend and show the plot
ax.legend()
plt.show()
