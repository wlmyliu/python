'''
hist_gen example
'''

import numpy as np
from matplotlib import colors
from matplotlib.ticker import PercentFormatter
from matplotlib import cm
from matplotlib import pyplot as plt

def gen_random_normal(rng, mu, sigma, n_points):
    X = mu + sigma * rng.standard_normal(n_points)
    print('x min max: ', round(X.min(), 2), round(X.max(), 2))
    return X 
#1 Create a random number generator with a fixed seed for reproducibility
rng = np.random.default_rng(20231129)

#2 define each array data
n_points = 100000 #2000
n_bins = 100

print_out = False
num_datasets = 2

#3 generate data
#dist0 = rng.standard_normal(N_points)
#dist1 = mu + sigma * rng.standard_normal(N_points)
mu = 0; sigma = 1
dist0 = gen_random_normal(rng, mu, sigma, n_points)
mu = 5; sigma = 10
dist1 = gen_random_normal(rng, mu, sigma, n_points)

dist = np.concatenate((dist0, dist1), axis=0).reshape(2, n_points)
if print_out:
    for i in range(num_datasets):
        print(dist[i]) 
    print(dist)

#4 subplot
fig, axs = plt.subplots(1, 2, sharey=True, tight_layout=True)
fig.canvas.manager.set_window_title('histogram 0 with empty and filled bars')

#5 set the number of bins with the *bins* keyword argument.
for i in range(num_datasets):
    if i % 2 == 0:
        axs[i].hist(dist[i], bins=n_bins, histtype='step', facecolor='g')
    else:
        axs[i].hist(dist[i], bins=n_bins, histtype='stepfilled', facecolor='tab:orange')
    axs[i].set_xlabel('x') 
    axs[i].set_ylabel('y')
    #fig.canvas.manager.set_window_title('histogram ' + str(i))

#6. plotting
fig, axs = plt.subplots(1, 2, tight_layout=True)
fig.canvas.manager.set_window_title('histogram 1 with colored bars and count / count% y-axes')

'''
7. create histgrams. bins_y is the count in each bin, while bins_x 
is the lower-limit of each bin, and patches are barContainers
'''
for i in range(2):
    if i == 0:
        bins_y, bins_x, patches = axs[i].hist(dist[i], bins=n_bins)
    else:
        bins_y, bins_x, patches = axs[i].hist(dist[i], bins=n_bins, density=True)
        axs[i].yaxis.set_major_formatter(PercentFormatter(xmax=1))
    
    bin_weights = bins_y / bins_y.max()
    if print_out:
        print('bins_y = ', bins_y, bins_y.max(), ': type:', type(bins_y), ', length = ', len(bins_y))
        print('bins_x = ', bins_x, ': type:', type(bins_x), ', length = ', len(bins_x))
        print('patches = ', patches, ': type:', type(patches), ', length = ', len(patches))

    # normalize  data to 0..1 for the full range of the colormap
    norm = colors.Normalize(bin_weights.min(), bin_weights.max())
    
    # loop through objects and set the color of each accordingly
    for weight, patch in zip(bin_weights, patches):
        #color = plt.viridis() 
        color = cm.viridis(norm(weight))
        patch.set_facecolor(color)  
    if i == 0:
        axs[i].set_xlabel('x') 
        axs[i].set_ylabel('bin count')
    else:
        axs[i].set_xlabel('x') 
        axs[i].set_ylabel('bin count %')
plt.show()