#1a. load with Python's built-in function open
print("1a: read with Python's built-in open function:")
csv_file = open("numbers.csv")
i = 0
for line in csv_file:
    print(i, line.rstrip()) # remove white spaces and \n at the end
    i += 1 # i++ and i += 1 will not work
#1b.1. read Python's csv module
print("\n1b.1: read with Python's csv module:")
import csv
with open("numbers.csv", 'r') as csv_file:
    csv_data = list(csv.reader(csv_file, delimiter=","))

#1b.2. convert to numpy array
print("\n1b.2: convert to numpy array:")
import numpy as np
csv_data = np.array(csv_data)
print(csv_data, type(csv_data))
  
#2a. Using NumPy's loadtxt function
print("\n2a: read with NumPy's loadtxt function:")
arr = np.loadtxt("numbers.csv", delimiter=",")
print(arr, type(arr))
    
#2b.  using NumPy's genfromtxt() function
print("\n2b: read with NumPy's genfromtxt function:")
arr = np.genfromtxt("numbers.csv", delimiter=",")
print(arr, type(arr))

#3a. using Pandas' read_csv function
from pandas import read_csv
print("\n3a: read with pandas' read_csv function:")
df = read_csv('numbers.csv')
print(df, type(df))
#3b: convert to numpy array
df_values = df.values
print('\n3b: converted to numpy array and print:\n', df_values, type(df_values))

