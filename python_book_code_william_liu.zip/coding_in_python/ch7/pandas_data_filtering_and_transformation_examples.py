import pandas as pd
import numpy as np

print('#1. get df with all columns')
df = pd.read_csv('weather_samples.csv')
print(df, '\n df type ', type(df))

print('\n#2. get selected columns')
df_selected_colums = pd.read_csv('weather_samples.csv',
        header=0,
        usecols=["max_wind_speed_kts", "max_wind_gust_kts"])
# printing dataframe
print(df_selected_colums, '\n df type ', type(df_selected_colums))

print('\n#3. get unique geos and cycle through geos:')
df_geos = df.geo.unique()
print(df_geos, '\ndf_geos type ', type(df_geos))
for geo in df_geos:
    print("geo:", geo, '->type of geo: ', type(geo))
    
print('\n#4. get unique stations for each geo:')
geo_station_dict = {}
for geo in df_geos:
    geo_stations = df[df.geo == geo]['station'].unique()
    print("geo:", geo, ", stations:", geo_stations, '-> type of stations: ', type(geo_stations))
    geo_station_dict[geo] = geo_stations
    
print("\n#5: transform dictionary of geo and stations:")
keys = geo_station_dict.keys()
station_dict = {}
for geo in keys:
    key = geo
    values = np.sort(geo_station_dict[geo])
    station_dict[key] = values
    print('geo = ', key, ': stations = ', values, ' type of values: ', type(values))

print("\n#6: traverse dictionary of geo and stations:")
for key in station_dict.keys():
    stations = station_dict.get(key)
    print('geo = ', key, ': stations = ', stations, ' type of stations: ', type(stations))

print("\n7: process each station data and print its min/max max_temperatures:")
print('type of the dictionary station_dict:', type(station_dict))
for key in station_dict.keys():
    stations = station_dict.get(key)
    for station in stations:
        # retrieve df series
        max_temp_series = df[df.station == station]['max_temp_f']
        print('type of max_temp_series:', type(max_temp_series))
        #min_max_temp = max_temp_series.min()
        #max_max_temp = max_temp_series.max()

        # convert df series to numpy ndarray
        max_temp_array = max_temp_series.to_numpy()
        min_max_temp = max_temp_array.min()
        max_max_temp = max_temp_array.max()       
        print('\ngeo = ', key, ', station = ', station)
        print('min_max_temp = ', min_max_temp, ', max_max_temp = ',  max_max_temp)
        print(max_temp_array)


