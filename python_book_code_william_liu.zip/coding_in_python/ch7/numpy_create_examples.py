#numpy  examples
import numpy as np

#1. Converting Python sequences to NumPy Arrays

arr_1d = np.array([1, 2, 3, 4, 5])
print('1d array:\n', arr_1d, '-->type:', type(arr_1d))

arr_2d = np.array([[1, 2, 3], [4, 5, 6]])
print('\n2d array:\n', arr_2d, '-->type:', type(arr_2d))
arr_3d = np.array([[[1, 2, 3], [4, 5, 6], [7, 8, 9]]])
print('\n3d array:\n', arr_3d, '-->type:', type(arr_3d))

#2. using np.arange to create 1d array
arr_1d_float = np.arange(2, 10, dtype=float) #start = 2.0, step = 1.0, last = 9.0
print('\n1d float element array:\n', arr_1d_float, '-->type:', type(arr_1d_float))

#3. using default_rng(seed)
from numpy.random import default_rng
seed = 99; row = 2; column = 3
rdm_2x3 = default_rng(seed).random((row,column))
print('\n 2x3 matrix with random elements:\n', rdm_2x3, '-->type:', type(rdm_2x3))

#4. using numpy random function
rdm_3x2 = np.random.rand(3,2)
print('\n 3x2 matrix with random float elements:\n', rdm_3x2, '-->type:', type(rdm_3x2))

#5. Generate a 2 x 4 array of ints between 0 and 4
rdm_int_2x4 = np.random.randint(5, size=(2, 4))
print('\n 2x4 matrix with random int elements:\n', rdm_int_2x4, '-->type:', type(rdm_int_2x4))

