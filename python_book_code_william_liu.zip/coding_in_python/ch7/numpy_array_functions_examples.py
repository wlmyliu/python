#numpy  function examples
import numpy as np

#1. reshape 1d array to 2x3
arr_1d = np.array([1, 2, 3, 4, 5, 6])
print('1d array:\n', arr_1d, '-->type:', type(arr_1d))
arr_2x3 = np.reshape(arr_1d, (2, 3))
print('reshape to 2 rows, 3 columns:\n', arr_2x3, '-->type:', type(arr_1d))

#2. using default_rng(seed)
from numpy.random import default_rng
seed = 99; row = 9; column = 1
rdm_9_rows = default_rng(seed).random((row, column))
print('\n2x3 matrix with random elements:\n', rdm_9_rows)

#3. compute the mean
mean_val = np.mean(rdm_9_rows)
print("mean:",mean_val)

#4. compute the median
median_val = np.median(rdm_9_rows)
print("median:",median_val)

#5. find the minimum and maximum
min_val = np.min(rdm_9_rows)
print("minimum:", min_val)

max_val = np.max(rdm_9_rows)
print("maximum:", max_val, '-->type:', type(max_val))

#6. multi-dimensional
#using default_rng(seed)
seed = 99; row = 5; column = 3
rdm_5x3 = default_rng(seed).random((row,column)) - 0.5
print('\n5x3 matrix with random elements:\n', rdm_5x3)

min_for_columns = np.min(rdm_5x3, axis = 0)
print('\n5x3 matrix with random elements. min for each column with axis = 0:\n', \
    min_for_columns, '-->type:', type(min_for_columns))

min_for_rows = np.min(rdm_5x3, axis = 1)
print('\n5x3 matrix with random elements. min for each row with axis = 1:\n', min_for_rows)

std_for_columns = np.std(rdm_5x3, axis = 0)
print('\n5x3 matrix with random elements. std for each column with axis = 0:\n', \
    std_for_columns, '-->type:', type(std_for_columns))