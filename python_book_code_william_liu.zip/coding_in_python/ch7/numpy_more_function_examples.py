#numpy  function examples
import numpy as np

#1. reshape 1d array to 2x3
arr_1d = np.array([1, 2, 3, 4, 5, 6])
print(np.power(arr_1d, 2))

arr_1d = 10 * arr_1d
print(arr_1d)
print(np.log10(arr_1d))
