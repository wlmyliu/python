# Python file i/o
#1. open and write
def hello():
    print("hello!")
file_name = "file_io_example.txt"
print("1. write file to", file_name)
with open(file_name, "w", encoding="utf-8") as f: 
    line = "Hello, Python!\n"
    f.write(line)
    print(line.strip())
    
    line = "Python is powerful!\n"
    f.write(line)
    print(line.strip())
    f.close()

#2. read file and process line by line
print("\n2. read file line by line from", file_name)
file = open(file_name, 'r')

for line in file:
    print(line.strip())

file.close()

#3. append() 
print("\n3. append to", file_name)
file = open(file_name, 'a')
line = "Hello, Python, again!\n"
print(line.strip())
file.write(line)

file.close()

# 4. read all lines in one call
print("\n4. read all lines in one call from", file_name)
file = open(file_name, 'r')
lines = file.readlines()

for line in lines:
    #print(line.strip())
    print(line)
