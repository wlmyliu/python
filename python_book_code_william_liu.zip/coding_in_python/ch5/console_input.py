# for strings
print('=>type a string', end =": ")
str_in = input()
print('string input:', str_in)

# for integers
print('=>type an integer', end =": ")
n = int(input())
print('integer input:', n)
      
print('=>type a floating number', end =": ")
# for floating numbers
f = float(input())
print('floating input:', f)

