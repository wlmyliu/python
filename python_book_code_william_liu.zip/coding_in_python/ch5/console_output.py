s = 'Hello, Python!'
print(s, end = ' <-> ')
print (repr(s), type(s))

x = 99/100
print(x, end = ' <-> ')
print (repr(x), type(repr(x)))

list1 = ['a', 'b', 'c']
print(list1, end = ' <-> ')
print(repr(list1), type(repr(list1)))

set1 = {1, 2, 3, 4, 5}
print(set1, end = ' <-> ')
print(repr(set1), type(repr(set1)))

for i in range (1, 10):
    print(repr(i).rjust(5), repr(i*i).rjust(5), repr(i*i*i).rjust(5))