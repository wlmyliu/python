import json

#write in json
json_file = "json_sample.json"

dict_obj = {
    "language": "python",
    "published": 2023,
    "price": "$29.99",
    "subject": "programming"
}

print("json file to write:", repr(dict_obj))
with open(json_file, "w") as outfile:
    json.dump(dict_obj, outfile)
    
#2. read json file
with open(json_file, 'r') as openfile:    
    json_object = json.load(openfile)
    print("json file read:", json_object)
    print("json file type:", type(json_object))
