dict1 = {"language": "Python", "message": "Hello!", "version": "2.7"}
print(dict1)

print(dict1.keys())

print(dict1.values())

dict1.update({"version": "3.7"})
print(dict1)

dict1.pop("version")
print(dict1)