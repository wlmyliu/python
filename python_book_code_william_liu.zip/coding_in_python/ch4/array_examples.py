# python array example
# a String as a character array

hello_str = "Hello, Python!"
n = len(hello_str) # length of array
print('hello_str length n = ', n)

for i in range (n): # print character by character
    print( hello_str[i], end = '')
else: 
    print('<- printed using index')

#slicing: positive indexing counting farward
print(hello_str[0 : 5], '<- slicing from indices 0 to 5')

#slicing: from negative index counting backward to the last char
print(hello_str[-7 : 14], '<- sclicing from indices -7 to 14')

#would not print the same substring as the above statement
print(hello_str[-7 : -1], '<- slicing from indices -7 to -1')

#would not print sliced substring
print(hello_str[-7 : 0], '<- slicing from indices -7 to 0')
