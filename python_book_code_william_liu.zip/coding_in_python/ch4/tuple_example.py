# tuple is a reserved word in python
tuple1 = (1, "Python", ('a', 'b'), [1, 2, 3])

print('print items one by one:')
for i in range(len(tuple1)):
    print('item ', i, ': value = ', tuple1[i], ', type:', type(tuple1[i]))

print('items from beginning to end:', end =' ')
print(tuple1[:])

print('items from index 1 to index 2:', end =' ')
print(tuple1[1 : 3])

print('items from index 2 to end:', end =' ')
print(tuple1[2:])

print(tuple1)
#tuple1.sort()
#print(tuple1)

#tuple1[0] = 2
