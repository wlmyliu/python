# list is a reserved word in python
list1 = [1, "Python", ('a', 'b'), [1, 2, 3]]
print('initial list:', list1)

print('print items one by one:')
for i in range(len(list1)):
    print('item ', i, ': value = ', list1[i], ', type:', type(list1[i]))

print('items from beginning to end:', end =' ')
print(list1[:])

print('items from index 1 to index 2:', end =' ')
print(list1[1 : 3])

print('items from index 2 to end:', end =' ')
print(list1[2:])

#list1.sort()
list1[0] = 2
print('items after changing the 1st element:', end =' ')
print(list1)