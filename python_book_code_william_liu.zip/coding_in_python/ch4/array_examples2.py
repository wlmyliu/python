# python array example 2
import array as arr

#an array of integer values
int_array = arr.array('i', [1, 2, 3])
print(int_array)

#an array of double values
double_array = arr.array('d', [1.0,2.0,3.0])
print(double_array)