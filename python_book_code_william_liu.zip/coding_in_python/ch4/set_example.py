set1 = {1, 'Python', 2.0, 'Hello!'}
print(set1)

set2 = {1, 'Python', 2.0, 'Hello!', [1, 2]}