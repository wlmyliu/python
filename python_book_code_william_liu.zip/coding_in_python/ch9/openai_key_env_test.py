import os
for key, value in sorted(os.environ.items()):
    print('{}: {}'.format(key, value))
key = os.getenv('OPENAI_API_KEY')
print('\nOPENAI_API_KEY:', key)
