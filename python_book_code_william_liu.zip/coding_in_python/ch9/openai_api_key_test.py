#import openai
import os
'''
The getpass() function is used to prompt to users 
using the string prompt and reads the input from the user as Password. 
'''
import getpass

# set enter and set OPEN_API_KEY
os.environ['OPENAI_API_KEY'] = getpass.getpass('OpenAI API Key:')

# retrieve OPENAI_API_KEY as am env variable
key = os.environ['OPENAI_API_KEY'] 
print('key  = ', key)