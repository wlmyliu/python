#min_temp: min =  18.0 on 1990-12-22 max =  78.0 on 2006-07-23
#max_temp: min =  0.0 on 2002-06-08 max =  131.0 on 1998-03-04
#max_temp max/min corrected with adjacent data to: max=(59+50)=55
# and min =(91+81)/2= 86 

import pandas as pd
import matplotlib.pyplot as plt 
import numpy as np
#1. define data file, attributes and figure properties
data_file = 'sac_weather_historical_corrected.csv'
print('data_file:', data_file)
attrib_x = "date"
attrib_y = ("max temperature (F)", "min temperature (F)")

title = "Sacramento weather daily min/max temperature (F) from 1947 to 2023"
width = 10; height = 7; x_axis_nbins = 10; grid = True; linewidth = 1.5
colors = plt.rcParams["axes.prop_cycle"]()
plt.rcParams.update({'font.size': 8})

#2. set and return plt fig and axes
def get_fig_ax():
    fig, ax = plt.subplots(figsize=(width, height))
    ax.grid(grid)

    plt.locator_params(axis='x', nbins = x_axis_nbins)
    ax.xaxis.set_major_locator(plt.MaxNLocator(5))
    ax.set_xlabel(attrib_x)  # Add an x-label to the axes.
    ax.set_ylabel(attrib_y)  # Add a y-label to the axes.
    ax.set_title(title)  # Add a title to the chart.
    return fig, ax

def get_min_max(label, x, y):
    min_val = y.min(); min_on = x[np.argmin(y)]
    max_val = y.max(); max_on = x[np.argmax(y)]
    print(label, 'min = ', min_val, 'on', min_on, \
        '; max = ', max_val, 'on', max_on )

#3. read data and print min max data and date for data sanity check
df = pd.read_csv("sac_weather_historical_corrected.csv", \
    usecols=["day", "min_temp_f", "max_temp_f"], skiprows = [26849,27213])
day = df["day"]
min_max_temp_f = df[["max_temp_f", "min_temp_f"]]

min_max_temp_data = min_max_temp_f.to_numpy()
get_min_max('max_temp:', day, min_max_temp_data[:, 0])
get_min_max('min_temp:',day, min_max_temp_data[:, 1])

#4. plot
#fig, ax = plt.subplots(2, 1, sharex=True) 
fig, ax = plt.subplots(2, 1) 
 
x = df["day"].to_numpy()

ax[0].set_title(title) # title
plt.locator_params(axis='x', nbins = x_axis_nbins)
columns = min_max_temp_data.shape[1]
for i in range(columns):
    y = min_max_temp_data[:, i]   
    ax[i].xaxis.set_major_locator(plt.MaxNLocator(7))
    ax[i].set_ylabel(attrib_y[i], fontsize=10)
    c = next(colors)["color"]
    #ax[i].plot(x[i:100], y[i:100], color=c, linestyle = 'dotted')
    ax[i].plot(x, y, color=c, linestyle = 'dotted')

plt.show()