openai_api_key = input("Enter your openai_api_key: ")
print("openai_api_key: ", openai_api_key )
