from openai import OpenAI
import util as util

my_api_key = util.get_api_key()
client = OpenAI(api_key=my_api_key);
'''
def chat_gpt(prompt):
    print(prompt)
    response = client.chat.completions.create(
        model = "text-embedding-ada-002", input = prompt
        #temperature = 0.7,
        #messages = [{"role": "user", "content": prompt}]
    )
    return result['data']['embedding']
question = "This is a test for testing embedding"
response = chat_gpt(question)
print(response)
'''
from openai import OpenAI
#client = OpenAI()

def get_embedding(text, model="text-embedding-ada-002"):
   text = text.replace("\n", " ")
   return client.embeddings.create(input = [text], model=model).data[0].embedding

question = "This is a test for testing embedding"
response = get_embedding(question)
length = len(response)
print('length of response', length, 'type: ', type(response))
print(response[0])
print(response[-1])
print(response)
'''
Enter your openai_api_key: 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
length of response 1536 type:  <class 'list'>
-0.026749316602945328 -> -0.02666674181818962
0.004302829969674349 -> 0.0043606627732515335

-0.02666674181818962
0.0043606627732515335

-0.02666674181818962
0.0043606627732515335

'''




