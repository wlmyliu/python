from openai import OpenAI
import util as util

my_api_key = util.get_api_key()
client = OpenAI(api_key=my_api_key);

def generate_pop_content(prompt):
    response = client.completions.create(
    engine = "text-davinci-003"
    #model="text-davinci-003",  
    prompt=prompt,
    temperature=0.7,  # Adjust the temperature for creativity
    max_tokens=100)

    return response.choices[0].text.strip()

prompt = "please show a python example for using openai"
popup_content = generate_pop_content(prompt)
print("Pop-up Content:")
print(popup_content)
