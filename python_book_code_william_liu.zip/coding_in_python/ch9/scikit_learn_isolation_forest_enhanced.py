'''
https://scikit-learn.org/stable/auto_examples/ensemble/plot_isolation_forest.html#sphx-glr-auto-examples-ensemble-plot-isolation-forest-py
'''
import numpy as np

from sklearn.model_selection import train_test_split
import util as util

#1. sample data generation using util
n_samples, n_outliers = 120, 40
rng = np.random.RandomState(0)

offset = np.array([2, 2])

cluster_1 = util.get_std_normal_data(rng, 0, 0.4, n_samples, 2, offset)

offset = np.array([-2, -2])
cluster_2 = util.get_std_normal_data(rng, 0, 0.3, n_samples, 2, offset)

X_outliers = util.get_uniform(rng, -4, 4, n_outliers, 2)

X = np.concatenate([cluster_1, cluster_2, X_outliers])

y = np.concatenate([np.ones((2 * n_samples), dtype=int), -np.ones((n_outliers), dtype=int)])

#mix train and test data
X_train, X_test, y_train, y_test = train_test_split(X, y, stratify = y, random_state = 42)

print('X_train type:', type(X_train))

#2. scatter plot with raw data
import matplotlib.pyplot as plt

scatter = plt.scatter(X[:, 0], X[:, 1], c=y, s=20, edgecolor="k")
handles, labels = scatter.legend_elements()
plt.axis("square")
plt.legend(handles=handles, labels=["outliers", "inliers"], title="true class")
plt.title("1. Raw Data: Gaussian inliers with \nuniformly distributed outliers", fontsize=10)

plt.show(block = False)

# 3. training
from sklearn.ensemble import IsolationForest

clf = IsolationForest(max_samples=100, random_state=0)
clf.fit(X_train)
y_pred_train = clf.predict(X_train)
y_pred_test = clf.predict(X_test)
y_pred_outliers = clf.predict(X_outliers)

label = 'outliers'
y_pred = y_pred_outliers
data_set = X_outliers
util.print_prediction(label, data_set, y_pred)

# 4. graphing: Inliers/Outliers by boundary
from sklearn.tree import DecisionTreeClassifier
from sklearn.inspection import DecisionBoundaryDisplay

disp = DecisionBoundaryDisplay.from_estimator(
    clf,
    X,
    response_method="predict",
    alpha=0.5,
)
disp.ax_.scatter(X[:, 0], X[:, 1], c=y, s=20, edgecolor="k")
disp.ax_.set_title("2. Inliers/Outliers by boundary: \nBinary decision boundary of IsolationForest", fontsize=10)
plt.axis("square")
plt.legend(handles=handles, labels=["outliers", "inliers"], title="true class")
plt.show(block = False)

# 5. graphing: Probability-based
disp = DecisionBoundaryDisplay.from_estimator(
    clf,
    X,
    response_method="decision_function",
    alpha=0.5,
)
disp.ax_.scatter(X[:, 0], X[:, 1], c=y, s=20, edgecolor="k")
disp.ax_.set_title("3. Probability-based: Path length \ndecision boundary of IsolationForest", fontsize=10)
plt.axis("square")
plt.legend(handles=handles, labels=["outliers", "inliers"], title="true class")
plt.colorbar(disp.ax_.collections[1])
plt.show()