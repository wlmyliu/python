import numpy as np

from numpy import where

def predict1(label, data_set, y_pred):
    #print(label + ':', 'outliers and inliers')
    anom_index = where(y_pred == -1)
    nom_index = where(y_pred == 1)
    anom_values = data_set[anom_index]
    nom_values = data_set[nom_index]
    print(label, " outlier/inlier ratio:", len(anom_values), ':', len(nom_values))
    print('outliers:\n', anom_values, '\ninliers:\n', nom_values)
    
def print_prediction(label, data_set, y_pred):
    print(label + ':', 'outliers and inliers')
    anom_index = where(y_pred == -1)
    nom_index = where(y_pred == 1)
    anom_values = data_set[anom_index]
    nom_values = data_set[nom_index]
    print('outliers: ', len(anom_values), '\n', anom_values)
    print('inliers:', len(nom_values), '\n', nom_values)
    
def get_std_normal_data(rng, mu, sigma, n_rows, n_columns, offset):
    X = mu + sigma * rng.randn(n_rows, n_columns) + offset
    print("normal_distribution_data:", X[0, :] , " - > ", X[n_rows - 1, :], "shape:",X.shape )
    return X

def get_uniform(rng, low, high, n_rows, n_columns):
    X = rng.uniform(low, high, size=(n_rows, n_columns))
    print("uniform: ", X[0, :] , " - > ", X[n_rows - 1, :], "shape ", X.shape)
    return X

def get_rng(seed):    
    #random_state = 42
    random_state = seed
    rng = np.random.RandomState(random_state)
    return rng

def get_api_key():
    openai_api_key = input("Enter your openai_api_key: ")
    return openai_api_key