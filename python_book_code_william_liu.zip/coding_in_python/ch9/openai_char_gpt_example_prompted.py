import openai

# Set your OpenAI API key
openai.api_key = 'my-api-key'

def generate_pop_content(prompt):
    response = openai.Completion.create(
        engine="text-davinci-003",  # You can use other engines as well
        prompt=prompt,
        temperature=0.7,  # Adjust the temperature for creativity
        max_tokens=100  # Adjust max tokens as needed
    )

    return response.choices[0].text.strip()

# Example prompt for a pop-up
#prompt = "Create a pop-up message that says:"
prompt = "please show a python example for using openai"
# Generate pop-up content
popup_content = generate_pop_content(prompt)

# Display the pop-up content
print("Pop-up Content:")
print(popup_content)
