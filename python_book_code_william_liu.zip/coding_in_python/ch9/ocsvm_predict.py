#ocsvm predict
import numpy as np
import util as util
from joblib import load

rbf_clf = load("rbf_ocsvm.joblib") 
sgd_clf = load("sgd_ocsvm.joblib") 

rng = util.get_rng(99)

n_train = 20; n_test = 10; n_outliers = 10

X = 0.4 * rng.randn(n_train, 2)
sample1 = np.r_[X + 2, X - 2]
print('sample1 shape:', sample1.shape)

X = 0.3 * rng.randn(n_test, 2) #120
sample2 = np.r_[X + 2, X - 2]

sample3 = rng.uniform(low = -4, high = 4, size=(n_outliers, 2))

sample_set = (sample1, sample2, sample3)
for i, sample in enumerate(sample_set):
    print("predict with sample" + str(i + 1))
    rbf_pred = rbf_clf.predict(sample)                     
    util.predict1('rbf_predicted', sample, rbf_pred)
  
    sgd_pred = sgd_clf.predict(sample) 
    util.predict1('sgd_predicted', sample, sgd_pred)
    print("---")