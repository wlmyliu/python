'''
https://scikit-learn.org/stable/auto_examples/linear_model/plot_sgdocsvm_vs_ocsvm.html#sphx-glr-auto-examples-linear-model-plot-sgdocsvm-vs-ocsvm-py
'''
import matplotlib
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.kernel_approximation import Nystroem
from sklearn.linear_model import SGDOneClassSVM
from sklearn.pipeline import make_pipeline
from sklearn.svm import OneClassSVM
import util as util

dump = False
def dump_clf(clf, filename):
    from joblib import dump
    dump(clf, filename)
    
#added: #[a.collections[0], b1, b2, c] causes error and odd behavior 
def get_plt_legend ():
    return plt.legend(
    ["training data", "test data","outlier data",],
    loc="upper left",
)

def get_sub_title(n_error_train, n_train, n_error_test, n_test, n_error_outliers, n_outliers):
    error_train_pct = str(round((n_error_train / n_train), 3)) + "%"
    error_test_pct = str(round((n_error_test / n_test), 3)) + "%"
    error_outlier_pct = str(round((n_error_outliers / n_outliers), 3)) + "%"
    error_train_label = str(n_error_train) + "/" +  str(n_train) + "=" + str(error_train_pct) + ", "
    error_test_label = "test: " + str(n_error_test) + "/" +  str(n_test) + "=" + str(error_test_pct) + ", "
    error_outlier_label = "outliers: " + str(n_error_outliers) + "/" +  str(n_outliers) + "=" + str(error_outlier_pct)
    
    return "Errors for train:" +  error_train_label + error_test_label + error_outlier_label

def get_min_max(label, x, y):
    min_val = y.min(); min_on = x[np.argmin(y)]
    max_val = y.max(); max_on = x[np.argmax(y)]
    print(label, 'min = ', min_val, 'on', min_on, \
        '; max = ', max_val, 'on', max_on )
    return min_val, max_val
    
def get_data_train_test_outliers (data_fileo):
    df = pd.read_csv(data_file, usecols=["day", "min_temp_f", "max_temp_f"])
    day = df["day"]
    #min for x-axis and max for y-axis
    max_min_temp_f = df[["min_temp_f", "max_temp_f"]]

    max_min_temp_data = max_min_temp_f.to_numpy()
    max_temp_min, max_temp_max = get_min_max('max_temp:', day, max_min_temp_data[:, 0])
    min_temp_min, min_temp_max = get_min_max('min_temp:',day, max_min_temp_data[:, 1])

    rows = max_min_temp_data.shape[0]
    columns = max_min_temp_data.shape[1]
    print('rows x columns:', rows, 'x', columns)

    n_train_start = 0; n_train_end = 25752 #1947-07-01 : 2017-12-31
    n_test_start = 25753; n_test_end = 26848 #2018-01-01 : 2020-12-31
    n_outlier_start = 26849; n_outlier_end = 27912 #2021-01-01 : 2023-11-30
    
    X_train = max_min_temp_data[n_train_start : n_train_end, :]
    X_test = max_min_temp_data[n_test_start : n_test_end :]
    x_outliers = max_min_temp_data[n_outlier_start : n_outlier_end :]
    print("n_train: (", (n_train_end - n_train_start + 1), ")", n_train_start, " -  ", n_train_end)
    print("n_test: (", n_test_end - n_test_start + 1, ")", n_test_start, " -  ", n_test_end)
    print("n_outliers: (", n_outlier_end - n_outlier_start + 1, ")", n_outlier_start, " -  ", n_outlier_end)
    f_min = 0.9; f_max = 1.1
    min_temp_min *= f_min; min_temp_max *= f_max; max_temp_min *= f_min; max_temp_max *= f_max
    return X_train, X_test, x_outliers, min_temp_min, min_temp_max, max_temp_min, max_temp_max

def train_predict_error(title, clf, xx, yy, X_train, X_test, X_outliers): 
    #predict       
    y_pred_train = clf.predict(X_train)
    y_pred_test = clf.predict(X_test)
    y_pred_outliers = clf.predict(X_outliers)
    util.print_prediction('X_outliers:', X_outliers, y_pred_outliers)
    
    # start plotting
    plt.figure(figsize=(9, 6))
    #plt.title(title)

    Z = clf.decision_function(np.c_[xx.ravel(), yy.ravel()])
    Z = Z.reshape(xx.shape)
    
    # contour first
    plt.contourf(xx, yy, Z, levels=np.linspace(Z.min(), 0, 7))
    plt.contour(xx, yy, Z, levels=[0], linewidths=2, colors="darkred")
    plt.contourf(xx, yy, Z, levels=[0, Z.max()], colors="palevioletred")
    # then  scatter
    s = 10
    plt.scatter(X_train[:, 0], X_train[:, 1], c="white", s=s, edgecolors="k")
    plt.scatter(X_test[:, 0], X_test[:, 1], c="blueviolet", s=s, edgecolors="k")
    plt.scatter(X_outliers[:, 0], X_outliers[:, 1], c="gold", s=s, edgecolors="k")

    n_error_train = y_pred_train[y_pred_train == -1].size
    n_error_test = y_pred_test[y_pred_test == -1].size
    n_error_outliers = y_pred_outliers[y_pred_outliers == -1].size

    get_plt_legend ()
    plt.xticks(fontsize = 10) 
    plt.yticks(fontsize = 10) 
    sub_title = get_sub_title(n_error_train, X_train.shape[0], n_error_test, X_test.shape[0], n_error_outliers, X_outliers.shape[0])
    plt.xlabel('min temperature (daily, F)', fontsize=10)
    plt.ylabel('max temperature (daily, F)', fontsize=10)
    
    plt.title(title + '\n' + sub_title, fontsize=10)

#main logic
font = {"weight": "normal", "size": 12}
matplotlib.rc("font", **font)

data_file = "sac_weather_historical_corrected.csv"
X_train, X_test, X_outliers, min_temp_min, min_temp_max, max_temp_min, max_temp_max = get_data_train_test_outliers (data_file)
xx_min = min_temp_min; xx_max = min_temp_max; yy_min = max_temp_min; yy_max = max_temp_max

num_ticks = 50
xx, yy = np.meshgrid(np.linspace(xx_min, xx_max, num_ticks), np.linspace(yy_min, yy_max, num_ticks))
print(xx_min, xx_max, yy_min, yy_max)

### OCSVM hyper-parameters
nu = 0.05; gamma = 0.02 #2.0
#1. Fit the One-Class SVM
clf = OneClassSVM(gamma = gamma, kernel="rbf", nu=nu)
clf.fit(X_train)
train_predict_error("Daily max-vs min-temperature for Sacramento since 1947 (RBF OCSVM)", clf, yy, xx, X_train, X_test, X_outliers)

#2. Fit the One-Class SVM using a kernel approximation and SGD
random_state = 42
tol=1e-4
transform = Nystroem(gamma = gamma, random_state=random_state)
clf_sgd = SGDOneClassSVM(
    nu=nu, shuffle=True, fit_intercept=True, random_state=random_state, tol = tol)

pipe_sgd = make_pipeline(transform, clf_sgd)
pipe_sgd.fit(X_train)

# pass pipe_sgd, not clf_sgd
train_predict_error("Daily max- vs min-temperature for Sacramento since 1947 (SGD OCSVM)", pipe_sgd, yy, xx, X_train, X_test, X_outliers)

plt.show()