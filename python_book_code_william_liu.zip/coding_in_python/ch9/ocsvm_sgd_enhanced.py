'''
https://scikit-learn.org/stable/auto_examples/linear_model/plot_sgdocsvm_vs_ocsvm.html#sphx-glr-auto-examples-linear-model-plot-sgdocsvm-vs-ocsvm-py
'''
import matplotlib
import matplotlib.pyplot as plt
import numpy as np

from sklearn.kernel_approximation import Nystroem
from sklearn.linear_model import SGDOneClassSVM
from sklearn.pipeline import make_pipeline
from sklearn.svm import OneClassSVM
import util as util

#added: #[a.collections[0], b1, b2, c] causes error and odd behavior 
def get_plt_legend ():
    return plt.legend(
    ["input training data", "input test data","input outlier data",],
    loc="upper left")
   
def get_plt_label(n_error_train, n_error_test, n_error_outliers):
    return plt.xlabel(
    "error ratios for train: %d/%d; test: %d/%d; outlier: %d/%d"
    % (n_error_train, X_train.shape[0], n_error_test, X_test.shape[0], 
       n_error_outliers,X_outliers.shape[0]))

def train_predict_error(title, clf, xx, yy, X_train, X_test, X_outliers): 
    # start plotting
    plt.figure(figsize=(9, 6))

    Z = clf.decision_function(np.c_[xx.ravel(), yy.ravel()])
    Z = Z.reshape(xx.shape)
    
    # contour first
    plt.contourf(xx, yy, Z, levels=np.linspace(Z.min(), 0, 7))
    plt.contour(xx, yy, Z, levels=[0], linewidths=2, colors="darkred")
    plt.contourf(xx, yy, Z, levels=[0, Z.max()], colors="palevioletred")
    
    # then  scatter
    s = 10
    plt.scatter(X_train[:, 0], X_train[:, 1], c="white", s=s, edgecolors="k")
    plt.scatter(X_test[:, 0], X_test[:, 1], c="blueviolet", s=s, edgecolors="k")
    plt.scatter(X_outliers[:, 0], X_outliers[:, 1], c="gold", s=s, edgecolors="k")

    y_pred_train = clf.predict(X_train)
    y_pred_test = clf.predict(X_test)
    y_pred_outliers = clf.predict(X_outliers)
    n_error_train = y_pred_train[y_pred_train == -1].size
    n_error_test = y_pred_test[y_pred_test == -1].size
    n_error_outliers = y_pred_outliers[y_pred_outliers == -1].size

    util.print_prediction('X_outliers:', X_outliers, y_pred_outliers)
    '''
    Z = clf.decision_function(np.c_[xx.ravel(), yy.ravel()])
    Z = Z.reshape(xx.shape)
    '''
    get_plt_legend ()
    get_plt_label(n_error_train, n_error_test, n_error_outliers)
    plt.title(title, fontsize=10)
    return clf

#1. main logic
font = {"weight": "normal", "size": 12}
matplotlib.rc("font", **font)

random_state = 42
rng = np.random.RandomState(random_state)
n_train = 500; n_test = 250; n_outliers = 250

# Generate train data by stacking two together
X = 0.4 * rng.randn(n_train, 2)

X_train = np.r_[X + 2, X - 2]

# Generate  regular novel observations
X = 0.3 * rng.randn(n_test, 2) #120
X_test = np.r_[X + 2, X - 2]
# Generate abnormal novel observations
X_outliers = rng.uniform(low=-4, high=4, size=(n_outliers, 2))
print('X_train, X_test, X_outliers shape: ', X_train.shape, X_test.shape, X_outliers.shape)

xx_min = -4.5; xx_max = 4.5; yy_min = -4.5; yy_max = 4.5; num_ticks = 50
xx, yy = np.meshgrid(np.linspace(xx_min, xx_max, num_ticks), np.linspace(yy_min, yy_max, num_ticks))

### OCSVM hyper-parameters
nu = 0.05
gamma = 2.0

#2. Fit the One-Class SVM
clf = OneClassSVM(gamma = gamma, kernel="rbf", nu=nu)
clf.fit(X_train)
train_predict_error("RBF OCSVM", clf, xx, yy, X_train, X_test, X_outliers)

plt.show(block = False)

#3. Fit the One-Class SVM using a kernel approximation and SGD
tol=1e-4
transform = Nystroem(gamma = gamma, random_state=random_state)
clf_sgd = SGDOneClassSVM(
    nu=nu, shuffle=True, fit_intercept=True, random_state=random_state, tol = tol)

pipe_sgd = make_pipeline(transform, clf_sgd)
pipe_sgd.fit(X_train)
# pass pipe_sgd, not clf_sgd
train_predict_error("SGD OCSVM", pipe_sgd, xx, yy, X_train, X_test, X_outliers)

plt.show()