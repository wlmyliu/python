'''
https://scikit-learn.org/stable/auto_examples/linear_model/plot_sgdocsvm_vs_ocsvm.html#sphx-glr-auto-examples-linear-model-plot-sgdocsvm-vs-ocsvm-py
'''
import matplotlib
import matplotlib.pyplot as plt
import numpy as np

from sklearn.kernel_approximation import Nystroem
from sklearn.linear_model import SGDOneClassSVM
from sklearn.pipeline import make_pipeline
from sklearn.svm import OneClassSVM
import util as util

import pickle

dump = False
def dump_clf(clf, filename):
    from joblib import dump
    dump(clf, filename)
    
#added: #[a.collections[0], b1, b2, c] causes error and odd behavior 
def get_plt_legend ():
    return plt.legend(
    ["input training data", "input test data","input outlier data",],
    loc="upper left",
)
   
def get_plt_x_y_limits(limit):
    return plt.xlim((-limit, limit)), plt.ylim((-limit, limit))

def get_plt_label(n_error_train, n_error_test, n_error_outliers):
    return plt.xlabel(
    "error ratios for train: %d/%d; test: %d/%d; outlier: %d/%d"
    % (n_error_train, X_train.shape[0], n_error_test, X_test.shape[0], 
       n_error_outliers,X_outliers.shape[0])
)

def train_predict_error(title, clf, xx, yy, X_train, X_test, X_outliers, limit): 
    plt.rcParams.update({'font.size': 10}) 
    y_pred_train = clf.predict(X_train)
    y_pred_test = clf.predict(X_test)
    y_pred_outliers = clf.predict(X_outliers)
    n_error_train = y_pred_train[y_pred_train == -1].size
    n_error_test = y_pred_test[y_pred_test == -1].size
    n_error_outliers = y_pred_outliers[y_pred_outliers == 1].size

    util.print_prediction('X_outliers:', X_outliers, y_pred_outliers)
    
    Z = clf.decision_function(np.c_[xx.ravel(), yy.ravel()])
    Z = Z.reshape(xx.shape)
    #plot_contour_scatter(xx, yy, Z, algorithm)
    
    # plot the level sets of the decision function
    plt.figure(figsize=(9, 6))
    plt.title(title)
    plt.contourf(xx, yy, Z, levels=np.linspace(Z.min(), 0, 7))
    plt.contour(xx, yy, Z, levels=[0], linewidths=2, colors="darkred")
    plt.contourf(xx, yy, Z, levels=[0, Z.max()], colors="palevioletred")
    
    s = 20
    plt.scatter(X_train[:, 0], X_train[:, 1], c="white", s=s, edgecolors="k")
    plt.scatter(X_test[:, 0], X_test[:, 1], c="blueviolet", s=s, edgecolors="k")
    plt.scatter(X_outliers[:, 0], X_outliers[:, 1], c="gold", s=s, edgecolors="k")

    get_plt_x_y_limits(limit)
    get_plt_legend ()
    get_plt_label(n_error_train, n_error_test, n_error_outliers)
    
    return clf

font = {"weight": "normal", "size": 12}
matplotlib.rc("font", **font)

random_state = 42
rng = np.random.RandomState(random_state)
n_train = 500; n_test = 250; n_outliers = 250

# Generate train data by stacking two together
X = 0.4 * rng.randn(n_train, 2)

X_train = np.r_[X + 2, X - 2]
print('X_train shape:', X_train.shape)

# Generate some regular novel observations
X = 0.3 * rng.randn(n_test, 2) #120
X_test = np.r_[X + 2, X - 2]
# Generate some abnormal novel observations
X_outliers = rng.uniform(low=-4, high=4, size=(n_outliers, 2))
print('X_train, X_test, X_outliers shape: ', X_train.shape, X_test.shape, X_outliers.shape)

xx_min = -4.5; xx_max = 4.5; yy_min = -4.5; yy_max = 4.5; num_ticks = 50
xx, yy = np.meshgrid(np.linspace(xx_min, xx_max, num_ticks), np.linspace(yy_min, yy_max, num_ticks))

### OCSVM hyper-parameters
nu = 0.05; gamma = 2.0
limit = 4.5
#1. Fit the One-Class SVM
clf = OneClassSVM(gamma = gamma, kernel="rbf", nu=nu)
clf.fit(X_train)
train_predict_error("RBF OCSVM", clf, xx, yy, X_train, X_test, X_outliers, limit)
plt.show(block = False)

#dump
if (dump):
    dump_clf(clf, "rbf_ocsvm.joblib")

#2. Fit the One-Class SVM using a kernel approximation and SGD
tol=1e-4
transform = Nystroem(gamma = gamma, random_state=random_state)
clf_sgd = SGDOneClassSVM(
    nu=nu, shuffle=True, fit_intercept=True, random_state=random_state, tol = tol)

pipe_sgd = make_pipeline(transform, clf_sgd)
pipe_sgd.fit(X_train)

# pass pipe_sgd, not clf_sgd
train_predict_error("SGD OCSVM", pipe_sgd, xx, yy, X_train, X_test, X_outliers, limit)

#dump
if (dump):
    dump_clf(pipe_sgd, "sgd_ocsvm.joblib")

plt.show()